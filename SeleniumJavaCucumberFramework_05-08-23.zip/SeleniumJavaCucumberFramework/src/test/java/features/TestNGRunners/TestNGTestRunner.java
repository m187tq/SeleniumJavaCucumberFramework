package features.TestNGRunners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//cucumber->  TestNG, junit

@CucumberOptions(features="src/test/java/features",
        glue="automationteststore.stepDefinitions",
        monochrome=true,
        tags = "@AccountRegistration",
        //tags = "@Accordion",
        //tags = "@Login",
        //tags = "@BrowserTabs",
        //tags = "@LoginPositive",
        //tags = "@Login_Both",
        plugin= {"html:target/cucumber.html"})

public class TestNGTestRunner extends AbstractTestNGCucumberTests{
   /*@Override
	@DataProvider(parallel=true)
	public Object[][] scenarios() {
		return super.scenarios();
	}*/
	
}
