package automationteststore.stepDefinitions;

import automationteststore.TestComponents.BaseTest;
import automationteststore.pageObjects.AccountPages.*;
import automationteststore.pageObjects.AddToCartPage;
import automationteststore.pageObjects.CartPages.CartPage;
import automationteststore.pageObjects.CartPages.CartSummary;
import automationteststore.pageObjects.CheckoutPages.*;
import automationteststore.pageObjects.HomePages.*;
import automationteststore.pageObjects.NavigationMenuPage;
import automationteststore.pageObjects.SearchResultPage;
import automationteststore.pageObjects.ShippingReturnsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;


public class e2eSteps extends BaseTest {
    public WebDriver driver;
    private AccountPage accountPage;
    private AccountLoginPage accountLoginPage;
    private AccountCreatePage accountCreatePage;
    private AccountEditPage accountEditPage;
    private AccountLogoutPage accountLogoutPage;
    private AccountSuccessPage accountSuccessPage;
    private HomePage homePage;
    private AddToCartPage addToCartPage;

    private NavigationMenuPage navigationMenuPage;
    private SearchResultPage searchResultPage;
    private ShippingReturnsPage shippingReturnsPage;
    private InvoiceOrderPage invoiceOrderPage;
    private MiddleMenuNaviPage middleMenuNaviPage;
    private FooterPage footerPage;
    private CheckoutBillingPage checkoutBillingPage;

    private CheckoutCartPage checkoutCartPage;
    private CheckoutConfirmationPage checkoutConfirmationPage;
    private CheckoutCustomerPage checkoutCustomerPage;
    private CheckoutPage checkoutPage;
    private CheckoutShippingModeEditPage checkoutShippingModeEditPage;
    private CheckoutSuccessPage checkoutSuccessPage;
    private PaymentModeEditPage paymentModeEditPage;
    private CartSummary cartSummary;
    private CartPage cartPage;

    @When("I clicks on search box and enter product name as {string} and click on search button")
    public void iClicksOnSearchBoxAndEnterProductNameAsAndClickOnSearchButton(String arg0) {
    }

    @And("I should be able to see search result item and click on add to cart button")
    public void iShouldBeAbleToSeeSearchResultItemAndClickOnAddToCartButton() {
    }

    @And("I input a number in quantity box to increases items by {string} and clicks on remove icon to remove from cart")
    public void iInputANumberInQuantityBoxToIncreasesItemsByAndClicksOnRemoveIconToRemoveFromCart(String arg0) {
    }

    @And("I starts all over again from the previous steps as {string} and increases items by {string}")
    public void iStartsAllOverAgainFromThePreviousStepsAsAndIncreasesItemsBy(String arg0, String arg1) {
    }

    @And("I verifies the product item by item image, unit price, quantity and grand total")
    public void iVerifiesTheProductItemByItemImageUnitPriceQuantityAndGrandTotal() {
    }

    @And("I click on the Checkout button")
    public void iClickOnTheCheckoutButton() {
    }

    @And("I inputted login Name as {string} and password as {string} and clicks on Login button")
    public void iInputtedLoginNameAsAndPasswordAsAndClicksOnLoginButton(String arg0, String arg1) {
    }

    @And("I on checkout confirmation page and validates all the order details displayed")
    public void iOnCheckoutConfirmationPageAndValidatesAllTheOrderDetailsDisplayed() {
    }

    @And("I click on confirm order button")
    public void iClickOnConfirmOrderButton() {
    }

    @And("I am presented with a checkout success page as {string}")
    public void iAmPresentedWithACheckoutSuccessPageAs(String arg0) {
    }

    @Then("I gets an order number as {string} and thank message displayed as {string}")
    public void iGetsAnOrderNumberAsAndThankMessageDisplayedAs(String arg0, String arg1) {
    }

    @And("I clicks on continue and logout button")
    public void iClicksOnContinueAndLogoutButton() {
    }

    @Then("I am back to home page")
    public void iAmBackToHomePage() {
    }

}



