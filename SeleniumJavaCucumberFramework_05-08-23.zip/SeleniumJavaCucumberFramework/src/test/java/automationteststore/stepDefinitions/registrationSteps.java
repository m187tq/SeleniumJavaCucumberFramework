package automationteststore.stepDefinitions;

import automationteststore.TestComponents.BaseTest;
import automationteststore.helper.assertion.AssertionHelper;
import automationteststore.helper.assertion.VerificationHelper;
import automationteststore.pageObjects.AccountPages.*;
import automationteststore.pageObjects.AddToCartPage;
import automationteststore.pageObjects.CartPages.CartPage;
import automationteststore.pageObjects.CartPages.CartSummary;
import automationteststore.pageObjects.CheckoutPages.*;
import automationteststore.pageObjects.HomePages.*;
import automationteststore.pageObjects.NavigationMenuPage;
import automationteststore.pageObjects.SearchResultPage;
import automationteststore.pageObjects.ShippingReturnsPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.io.IOException;


public class registrationSteps extends BaseTest {
    public WebDriver driver;
    private AccountPage accountPage;
    private AccountLoginPage accountLoginPage;
    public AccountCreatePage accountCreatePage;
    private AccountEditPage accountEditPage;
    private AccountLogoutPage accountLogoutPage;
    private AccountSuccessPage accountSuccessPage;
    private HomePage homePage;
    private AddToCartPage addToCartPage;

    private NavigationMenuPage navigationMenuPage;
    private SearchResultPage searchResultPage;
    private ShippingReturnsPage shippingReturnsPage;
    private InvoiceOrderPage invoiceOrderPage;
    private MiddleMenuNaviPage middleMenuNaviPage;
    private FooterPage footerPage;
    private CheckoutBillingPage checkoutBillingPage;

    private CheckoutCartPage checkoutCartPage;
    private CheckoutConfirmationPage checkoutConfirmationPage;
    private CheckoutCustomerPage checkoutCustomerPage;
    private CheckoutPage checkoutPage;
    private CheckoutShippingModeEditPage checkoutShippingModeEditPage;
    private CheckoutSuccessPage checkoutSuccessPage;
    private PaymentModeEditPage paymentModeEditPage;
    private CartSummary cartSummary;
    private CartPage cartPage;

    @Given("I am on index page url as {string} and page title as {string}")
    public void iAmOnIndexPageUrlAsAndPageTitleAs(String pageUrl, String pageTitle) {
        AssertionHelper.updateTestStatus(homePage.getCurrentPageUrl().equalsIgnoreCase(pageUrl));
        AssertionHelper.updateTestStatus(homePage.getCurrentPageTitle().equalsIgnoreCase(pageTitle));
    }

    @When("I clicks on Login Or RegisterTest link")
    public void iClicksOnLoginOrRegisterLink() throws IOException {
        accountLoginPage = homePage.clickLoginOrRegisterLink();
    }

    @And("I should be on account login page with option to login as {string} or create an Account as {string}")
    public void iShouldBeOnAccountLoginPageWithOptionToLoginAsOrCreateAnAccountAs(String returningCustomer, String newCustomer) {
        AssertionHelper.updateTestStatus(accountLoginPage.getReturningCustomerTxt().equalsIgnoreCase(returningCustomer));
        AssertionHelper.updateTestStatus(accountLoginPage.getNewCustomerTxt().equalsIgnoreCase(newCustomer));
    }

    @And("I tap on Continue button in account login page")
    public void iClickOnContinueButton() throws IOException {
        accountCreatePage = accountLoginPage.clickOnContinueRegisterAccountBtn();
    }

    @And("I am on account create page and verifies page heading as {string} and page Url contains {string}")
    public void iAmOnAccountCreatePageAndVerifiesPageHeadingAsAndPageUrlContains(String pageHeader, String pageUrl) {
        AssertionHelper.updateTestStatus(accountCreatePage.getCreateAccountTxt().equalsIgnoreCase(pageHeader));
        AssertionHelper.updateTestStatus(accountCreatePage.getCurrentPageUrl().equalsIgnoreCase(pageUrl));
    }

    @And("I can see personal details in {string}")
    public void iCanSeePersonalDetailsIn(String personalDetail) {
        AssertionHelper.updateTestStatus(accountCreatePage.getYourPersonalDetailsTxt().equalsIgnoreCase(personalDetail));
    }

    @And("I inputted First name {string}")
    public void iInputtedFirstNameBoxAsFirstName(String firstname) {
        accountCreatePage.enterFirstName(firstname);
    }

    @And("I inputted Last name {string}")
    public void iInputtedLastNameBoxAsLastName(String lastname) {
        accountCreatePage.enterLastName(lastname);
    }

    @And("I inputted fresh email")
    public void iInputtedFreshEmail() {
        accountCreatePage.enterEmailAddress();
    }

    @And("I inputted Telephone {int}")
    public void iInputtedTelephoneBoxAs(int tel) {
        accountCreatePage.enterTelephoneNumber(String.valueOf(tel));
    }

    @And("I inputted Fax {int}")
    public void iInputtedFax(int fax) {
        accountCreatePage.enterFaxNumber(String.valueOf(fax));
    }

    @And("I can see Address Section {string}")
    public void iCanSeeAddressSectionAs(String addrSection) {
        AssertionHelper.updateTestStatus(accountCreatePage.getYourAddressText().equalsIgnoreCase(addrSection));
    }

    @And("I inputted Company name {string}")
    public void iInputtedCompanyNameYourCompanyName(String coyName) {
        accountCreatePage.enterCompanyName(coyName);
    }

    @And("I inputted Address One {string}")
    public void iInputtedAddressOneYourAddress(String addr1) {
        accountCreatePage.enterAddress1(addr1);
    }

    @And("I inputted Address Two {string}")
    public void iInputtedAddressTwoYourAddress(String addr2) {
        accountCreatePage.enterAddress2(addr2);
    }

    @And("I inputted City {string}")
    public void iInputtedCity(String city) {
        accountCreatePage.enterCity(city);
    }

    @And("I inputted Region or State {string}")
    public void iInputtedRegionOrState(String regionOrState) {
        accountCreatePage.selectRegionState(regionOrState);
    }

    @And("I inputted Zip or postal Code {string}")
    public void iInputtedZIPCode(String postalalOrZipCode) {
        accountCreatePage.enterZipCode(postalalOrZipCode);
    }

    @And("I inputted Country {string}")
    public void iInputtedCountry(String country) {
        accountCreatePage.selectCountry(country);
    }

    @And("I can see login section {string}")
    public void iCanSeeLoginSection(String loginDetails) throws IOException {
        AssertionHelper.updateTestStatus(accountCreatePage.getLoginDetailsSectionTxt().equalsIgnoreCase(loginDetails));


    }

    @And("I inputted loginName")
    public void iInputtedLoginNameInLoginNameBox() {
        accountCreatePage.enterLoginName();
    }

    @And("I inputted password {string}")
    public void iInputtedPasswordInPasswordBoxAs(String password) {
        accountCreatePage.enterPassword(password);
    }

    @And("I inputted confirm password {string}")
    public void iInputtedConfirmPasswordInPasswordConfirmBoxAs(String password) {
        accountCreatePage.enterPasswordConfirm(password);
    }

    @And("I subscribed to Newsletter and check on Yes")
    public void iSubscribedToNewsletterAndCheckOnYes() {
        accountCreatePage.tickOnSubscribeAsYes();
    }

    @And("I tick on read and agree to the Privacy Policy radio button")
    public void iTickOnReadAndAgreeToThePrivacyPolicyRadioButton() {
        accountCreatePage.checkOnIAgreeToPrivacyPolicyRadioButton();
    }

    @And("I clicks on Continue button")
    public void iClicksOnContinueButton() {
    }

    @Then("I should see success confirmation message {string}")
    public void iShouldSeeSuccessConfirmationMessage(String arg0) {
    }

    @And("I gets congratulatory message {string}")
    public void iGetsCongratulatoryMessage(String arg0) {
    }

    @And("I clicks on Continue button in Account Success page")
    public void iClicksOnContinueAccountSuccessButton() {
    }

    @And("I am on Account page and presented with welcome message {string}")
    public void iAmOnAccountPageAndPresentedWithWelcomeMessage(String welcomeMsg) {
    }

    @When("I clicks on logoff button on Account page")
    public void iClicksOnLogoffButtonOnAccountPage() {
    }

    @And("I should be on account logout page url contains {string}")
    public void iShouldBeOnAccountLogoutPageUrlContains(String urlPath) {
    }

    @And("I clicks on logout Continue Button")
    public void iClicksOnLogoutContinueButton() {
    }


    @Given("I am on account login page {string} and {string}")
    public void iAmOnAccountLoginPageAnd(String arg0, String arg1) {
    }

    @And("I can see {string} in account login page")
    public void iCanSeeInAccountLoginPage(String arg0) {
    }


    @And("I can see page title as {string} and heading text as {string}")
    public void iCanSeePageTitleAsAndHeadingTextAs(String arg0, String arg1) {
    }

    @And("I should see the create account form")
    public void iShouldSeeTheCreateAccountForm() {
    }

    @And("I should see the create account {string}")
    public void iShouldSeeTheCreateAccount(String arg0) {
    }

    @And("I can see input sections as {string}, {string}, {string} and {string}")
    public void iCanSeeInputSectionsAsAnd(String arg0, String arg1, String arg2, String arg3) {
    }

    @And("I can see labels as {int} as first label as {string} and last as {string}")
    public void iCanSeeLabelsAsAsFirstLabelAsAndLastAs(int arg0, String arg1, String arg2) {
    }

    @And("I input firstName as {string}")
    public void iInputFirstNameAs(String arg0) {
    }

    @And("I input lastName as {string}")
    public void iInputLastNameAs(String arg0) {
    }

    @And("I input emailAddress")
    public void iInputEmailAddress() {
    }

    @And("I input telephone as {string}")
    public void iInputTelephoneAs(String arg0) {
    }

    @And("I input fax as {string}")
    public void iInputFaxAs(String arg0) {
    }

    @And("I input company as {string}")
    public void iInputCompanyAs(String arg0) {
    }

    @And("I input Address one as {string}")
    public void iInputAddressOneAs(String arg0) {
    }

    @And("I input Address two as {string}")
    public void iInputAddressTwoAs(String arg0) {
    }

    @And("I input city as {string}")
    public void iInputCityAs(String arg0) {
    }

    @And("I select region or province {string}")
    public void iSelectRegionOrProvince(String arg0) {
    }

    @And("I input zipCodeOrPostCode as {string}")
    public void iInputZipCodeOrPostCodeAs(String arg0) {
    }

    @And("I select {string} country from the dropdown")
    public void iSelectCountryFromTheDropdown(String arg0) {
    }

    @And("I input loginName")
    public void iInputLoginName() {
    }

    @And("I input password as {string}")
    public void iInputPasswordAs(String arg0) {
    }

    @And("I input confirm password as {string}")
    public void iInputConfirmPasswordAs(String arg0) {
    }

    @And("I can see subscription option {string}")
    public void iCanSeeSubscriptionOption(String arg0) {
    }

    @And("I tick on subscription option Yes")
    public void iTickOnSubscriptionOptionYes() {
    }

    @And("I can see option No is not checked")
    public void iCanSeeOptionNoIsNotChecked() {
    }

    @And("I tick on subscription option No")
    public void iTickOnSubscriptionOptionNo() {
    }

    @And("I tick on {string} radio button")
    public void iTickOnRadioButton(String arg0) {
    }

    @And("I can see {string} button")
    public void iCanSeeButton(String arg0) {
    }

    @Then("I should see {string} in Account success page")
    public void iShouldSeeInAccountSuccessPage(String arg0) {
    }

    @And("I tap on Continue button in Account success page")
    public void iTapOnContinueButtonInAccountSuccessPage() {
    }

    @And("I can see {string} and {string} in account page")
    public void iCanSeeAndInAccountPage(String arg0, String arg1) {
    }

    @And("I tap on Logoff icon")
    public void iTapOnLogoffIcon() {
    }

    @And("I see a {string} button")
    public void iSeeAButton(String arg0) {
    }

    @And("I tap on Continue button in account logout page")
    public void iTapOnContinueButtonInAccountLogoutPage() {
    }

    @And("navigates to home page and I can see {string}")
    public void navigatesToHomePageAndICanSee(String arg0) {
    }

    @Then("I should see red warning error message {string}")
    public void iShouldSeeRedWarningErrorMessage(String arg0) {
    }

    @And("I can see {string} must be between {int} and {int} characters!")
    public void iCanSeeMustBeBetweenAndCharacters(String arg0, int arg1, int arg2) {
    }

    @And("I can see Last Name must be between {int} and {int} characters")
    public void iCanSeeLastNameMustBeBetweenAndCharacters(int arg0, int arg1) {
    }

    @And("I can see {string} does not appear to be valid!")
    public void iCanSeeDoesNotAppearToBeValid(String arg0) {
    }

    @And("I can see Address{int} must be between {int} and {int} characters!")
    public void iCanSeeAddressMustBeBetweenAndCharacters(int arg0, int arg1, int arg2) {
    }

    @And("I can see City must be between {int} and {int} characters!")
    public void iCanSeeCityMustBeBetweenAndCharacters(int arg0, int arg1) {
    }

    @And("I can see {string} a region state")
    public void iCanSeeARegionState(String arg0) {
    }

    @And("I can see Zip or postal code\" must be between {int} and {int} characters!")
    public void iCanSeeZipOrPostalCodeMustBeBetweenAndCharacters(int arg0, int arg1) throws Throwable {    // Write code here that turns the phrase above into concrete actions    throw new cucumber.api.PendingException();}
}

    @And("I can see {string} must be alphanumeric only and between {int} and {int} characters!")
    public void iCanSeeMustBeAlphanumericOnlyAndBetweenAndCharacters(String arg0, int arg1, int arg2) {
    }

    @And("I can see Password must be between {int} and {int} characters!")
    public void iCanSeePasswordMustBeBetweenAndCharacters(int arg0, int arg1) {
    }

    @And("I should see {int} mandatory red icons")
    public void iShouldSeeMandatoryRedIcons(int arg0) {
        
    }

    @And("I tap on Continue button")
    public void iTapOnContinueButton() {
    }

    @When("I tap on Continue button in create account page")
    public void iTapOnContinueButtonInCreateAccountPage() {
    }

    @And("I tap continue button in account login page")
    public void iTapContinueButtonInAccountLoginPage() {

    }
}

