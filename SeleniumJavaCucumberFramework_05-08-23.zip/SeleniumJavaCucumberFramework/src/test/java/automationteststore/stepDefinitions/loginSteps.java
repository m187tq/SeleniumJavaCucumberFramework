package automationteststore.stepDefinitions;

import automationteststore.TestComponents.BaseTest;
import automationteststore.helper.assertion.AssertionHelper;
import automationteststore.helper.assertion.VerificationHelper;
import automationteststore.helperutilities.GlobalVars;
import automationteststore.pageObjects.AccountPages.*;
import automationteststore.pageObjects.AddToCartPage;
import automationteststore.pageObjects.CartPages.CartPage;
import automationteststore.pageObjects.CartPages.CartSummary;
import automationteststore.pageObjects.CheckoutPages.*;
import automationteststore.pageObjects.HomePages.*;
import automationteststore.pageObjects.NavigationMenuPage;
import automationteststore.pageObjects.SearchResultPage;
import automationteststore.pageObjects.ShippingReturnsPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.io.IOException;


public class loginSteps extends BaseTest {
    public WebDriver driver;
    public AccountPage accountPage;
    public AccountLoginPage accountLoginPage;
    public AccountCreatePage accountCreatePage;
    private AccountEditPage accountEditPage;
    private AccountLogoutPage accountLogoutPage;
    private AccountSuccessPage accountSuccessPage;
    private HomePage homePage;
    private AddToCartPage addToCartPage;

    private NavigationMenuPage navigationMenuPage;
    private SearchResultPage searchResultPage;
    private ShippingReturnsPage shippingReturnsPage;
    private InvoiceOrderPage invoiceOrderPage;
    private MiddleMenuNaviPage middleMenuNaviPage;
    private FooterPage footerPage;
    private CheckoutBillingPage checkoutBillingPage;

    private CheckoutCartPage checkoutCartPage;
    private CheckoutConfirmationPage checkoutConfirmationPage;
    private CheckoutCustomerPage checkoutCustomerPage;
    private CheckoutPage checkoutPage;
    private CheckoutShippingModeEditPage checkoutShippingModeEditPage;
    private CheckoutSuccessPage checkoutSuccessPage;
    private PaymentModeEditPage paymentModeEditPage;
    private CartSummary cartSummary;
    private CartPage cartPage;


    @Given("I am in Ecommerce home Page {string}")
    public void iAmInEcommerceHomePage(String url) throws IOException {
        homePage = launchApplication();
        AssertionHelper.updateTestStatus(homePage.getCurrentPageUrl().equalsIgnoreCase(url));
        AssertionHelper.updateTestStatus(homePage.getCurrentPageTitle().equalsIgnoreCase(GlobalVars.getHomePageTitle()));
        new VerificationHelper(driver).isDisplayed(homePage.logoImage);

    }

    @And("I navigate to login page")
    public void iNavigateToLoginPage() throws IOException {
        new VerificationHelper(driver).isDisplayed(homePage.loginOrRegisterLink);
        accountLoginPage = homePage.clickLoginOrRegisterLink();
    }

    @And("I can see {string} and {string} sub headings texts")
    public void iCanSeeAndSubHeadingsTexts(String returingCustomer, String newCustomer) {
        boolean status = accountLoginPage.returningCustomerTxt.getText().equalsIgnoreCase(returingCustomer);
        AssertionHelper.updateTestStatus(status);
        boolean statusForNewCustomer = accountLoginPage.newCustomerTxt.getText().equalsIgnoreCase(newCustomer);
        AssertionHelper.updateTestStatus(statusForNewCustomer);
    }

    @And("I login {string} and {string}")
    public void iLoginAnd(String loginName, String password) {
        accountLoginPage.enterLoginName(loginName);
        accountLoginPage.enterPassword(password);
    }

    @And("I tap on Login button")
    public void iTapOnLoginButton() throws IOException {
        accountPage = accountLoginPage.clickOnLoginBtn();
    }

    @Then("should be presented with the following validation message as {string}")
    public void shouldBePresentedWithTheFollowingValidationMessageAs(String loginValidationMessage) {
        boolean status = accountPage.getWelcomeMessageTxt().contains(loginValidationMessage);
        AssertionHelper.updateTestStatus(status);
    }
    @Then("should be presented with the following Error validation message as {string}")
    public void shouldBePresentedWithTheFollowingErrorValidationMessageAs(String loginValidationErrorMessage) {
        boolean status = accountLoginPage.getErrorIncorrectLoginPasswordProvidedConfirmationMessageTxt().contains(loginValidationErrorMessage);
        AssertionHelper.updateTestStatus(status);
    }

    @And("I tap on edit profile button")
    public void iTapOnEditProfileButton() throws IOException {
        accountEditPage = accountPage.clickOnEditAccountDetailsLink();
    }

    @And("inputted the following details")
    public void inputtedTheFollowingDetails(DataTable dataTable) {
        accountEditPage.enterFirstName(dataTable.cell(1, 0));
        accountEditPage.enterLastName(dataTable.cell(1, 1));
        accountEditPage.enterTelephone(dataTable.cell(1, 2));
        accountEditPage.enterFax(dataTable.cell(1, 3));
    }

    @And("clicks on Continue button")
    public void clicksOnContinueButton() throws IOException {
        accountPage = accountEditPage.clickOnContinueEditBtn();
    }

    @And("I should see confirmation message {string}")
    public void getConfirmationMessage(String successMsg) {
        boolean status = accountPage.getAccountProfileSuccessfulUpdateMessage().trim().contains(successMsg);
        AssertionHelper.updateTestStatus(status);
    }

    @Then("I am taken back to home page url {string} and page title as {string}")
    public void iAmTakenBackToHomePageUrlAndPageTitleAs(String url, String title) {
        AssertionHelper.updateTestStatus(homePage.getCurrentPageUrl().equalsIgnoreCase(url));
        AssertionHelper.updateTestStatus(homePage.getCurrentPageTitle().equalsIgnoreCase(title));
        new VerificationHelper(driver).isDisplayed(homePage.logoImage);
    }

    @When("I clicks on logoff button")
    public void iClicksOnLogoffButton() throws IOException {
        accountLogoutPage = accountPage.clickOnLogoffBtn();
    }

    @And("I tap logout Continue Button")
    public void iTapLogoutContinueButton() throws IOException {
        homePage = accountLogoutPage.clickOnLogoutContinueButton();
    }
}



