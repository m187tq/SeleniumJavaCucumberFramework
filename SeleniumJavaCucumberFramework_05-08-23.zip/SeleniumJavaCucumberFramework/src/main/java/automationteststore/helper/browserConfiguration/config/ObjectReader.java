package automationteststore.helper.browserConfiguration.config;

public class ObjectReader {

	public static ConfigReader reader;
}
