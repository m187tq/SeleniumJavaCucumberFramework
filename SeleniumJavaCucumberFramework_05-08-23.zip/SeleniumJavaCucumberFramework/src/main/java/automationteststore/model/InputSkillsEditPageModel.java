package automationteststore.model;

public class InputSkillsEditPageModel extends FieldInputModel {
	public InputSkillsEditPageModel() {
		fieldInputData.put("Skill Category", "Communication");
		fieldInputData.put("Essential Skill", "EDITED Worked as part of a large team.");
		fieldInputData.put("Desirable Skill", "EDITED Attended social evenings for team bonding.");
	}
}
