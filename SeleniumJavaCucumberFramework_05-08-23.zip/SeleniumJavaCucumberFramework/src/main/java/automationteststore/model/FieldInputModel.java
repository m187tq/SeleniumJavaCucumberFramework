package automationteststore.model;

import java.util.HashMap;
import java.util.Map;

public class FieldInputModel {

	protected Map<String, String> fieldInputData = new HashMap<>();

	public FieldInputModel() {
	}

	public Map<String, String> getFieldInputData() {
		return fieldInputData;
	}

}
