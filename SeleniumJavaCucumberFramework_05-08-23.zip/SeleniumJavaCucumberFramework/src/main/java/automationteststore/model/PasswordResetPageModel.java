package automationteststore.model;

public class PasswordResetPageModel extends FieldInputModel {

	public PasswordResetPageModel() {
		fieldInputData.put("email", "automation@test.com");
	}

}
