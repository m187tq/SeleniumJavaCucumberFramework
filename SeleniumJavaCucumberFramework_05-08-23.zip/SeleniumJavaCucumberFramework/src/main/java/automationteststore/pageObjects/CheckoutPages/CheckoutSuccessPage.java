package automationteststore.pageObjects.CheckoutPages;

import automationteststore.AbstractComponents.AbstractComponent;
import automationteststore.helper.logger.LoggerHelper;
import automationteststore.pageObjects.AccountPages.AccountCreatePage;
import automationteststore.pageObjects.HomePages.HomePage;
import automationteststore.pageObjects.HomePages.InvoiceOrderPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class CheckoutSuccessPage extends AbstractComponent {
    public WebDriver driver;
    Logger log = LoggerHelper.getLogger(AccountCreatePage.class);
    public CheckoutSuccessPage(WebDriver driver) throws IOException {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String orderSuccessPageUrl = "https://automationteststore.com/index.php?rt=checkout/success";

    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div/div/div/h1/span[1]")
    private WebElement yourOrderHasBeenProcessedHeadingTxt;

    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div/div/div/div/section/p[2]")
    private WebElement OrderNumberText;

    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div/div/div/div/section/p[3]")
    private WebElement viewInvoiceText;

    @FindBy(xpath = "//p[contains(text(),'Thank you for shopping with us!')]")
    private WebElement thankYouForShoppingWithUsText;

    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div/div/div/div/section/p[3]")
    private WebElement invoicePageLink;

    @FindBy(xpath = "//*[@id=\"maincontainer\"]/div/div/div/div/section/a")
    private WebElement continueCheckoutSuccessBtn;

    public String getOrderSuccessPageUrl() {
        return orderSuccessPageUrl;
    }

    public String getYourOrderHasBeenProcessedHeadingTxt() {
        return verificationHelper.getText(yourOrderHasBeenProcessedHeadingTxt);
    }

    public String getOrderNumberText() {
        return verificationHelper.getText(OrderNumberText);
    }

    public String getViewInvoiceText() {
        return verificationHelper.getText(viewInvoiceText);
    }

    public String getThankYouForShoppingWithUsText() {
        return verificationHelper.getText(thankYouForShoppingWithUsText);
    }

    public InvoiceOrderPage clickOnInvoicePageLink() throws IOException {
        waitForWebElementAndClick(invoicePageLink);
        return new InvoiceOrderPage(driver);
    }

    public HomePage clickOnContinueCheckoutSuccessBtn() throws IOException {
        waitForWebElementAndClick(continueCheckoutSuccessBtn);
        return new HomePage(driver);
    }

}
