package automationteststore.pageObjects.ApplicationText;

public class appText {

    //ProductCategoryPage
    public static final String Black = "Black";
    public static final String Orange = "Orange";
    public static final String Yellow = "Yellow";
    public static final String HOME = "HOME";
    public static final String APPARELANDACCESSORIES = "APPARELANDACCESSORIES";
    public static final String MAKEUP = "MAKEUP";
    public static final String SKINCARE = "SKINCARE";
    public static final String FRAGRANCE = "FRAGRANCE";
    public static final String MEN = "MEN";
    public static final String HAIRCARE = "HAIRCARE";
    public static final String BOOKS = "BOOKS";

}
