package automationteststore.pageObjects.ApplicationText;

public class ApplicationText {

    // ProductCategoryPage
    public static final String Black = "Black";
    public static final String Orange = "Orange";
    public static final String Yellow = "Yellow";

    // HomePages
    public static final String Tshirts = "T-shirts";
    public static final String Blouses = "Blouses";
    public static final String CasualDresses = "Casual Dresses";
}
