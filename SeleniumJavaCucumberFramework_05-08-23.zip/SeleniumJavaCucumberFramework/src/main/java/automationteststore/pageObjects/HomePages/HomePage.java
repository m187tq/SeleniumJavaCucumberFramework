package automationteststore.pageObjects.HomePages;

import automationteststore.AbstractComponents.AbstractComponent;
import automationteststore.helper.logger.LoggerHelper;
import automationteststore.pageObjects.AccountPages.AccountLoginPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;
import java.util.List;


public class HomePage extends AbstractComponent {

    public WebDriver driver;
    Logger log = LoggerHelper.getLogger(HomePage.class);

    public HomePage(WebDriver driver) throws IOException {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }

    public final String url = "https://automationteststore.com/";

    @FindBy(css = ".navbar-header.header-logo")
    public WebElement logoImage;

    @FindBy(css = ".welcome_msg h4")
    public WebElement welcome_msg;

    @FindBy(name = "")
    public WebElement fastShippingTxt;
    @FindBy(name = "")
    public WebElement easyPaymentsTxt;
    @FindBy(name = "")
    public WebElement shippingOptionsTxt;
    @FindBy(name = "")
    public WebElement largeVarietyTxt;
    @FindBy(name = "")
    public List<WebElement> featuredProducts;
    @FindBy(name = "")
    public WebElement homePageSlider;
    @FindBy(name = "")
    public List<WebElement> containerFeaturedProducts;
    @FindBy(name = "")
    public WebElement footerBanners;
    @FindBy(name = "")
    public List<WebElement> latestProducts;
    @FindBy(name = "")
    public List<WebElement> bestSellerProducts;
    @FindBy(name = "")
    public List<WebElement> specialProducts;
    @FindBy(name = "")
    public List<WebElement> BrandScrollingList;
    @FindBy(name = "")
    public WebElement contactUs;
    @FindBy(name = "")
    public WebElement aboutUs;
    @FindBy(name = "")
    public WebElement testimonials;
    @FindBy(name = "")
    public WebElement newsletterSignUpsTxt;
    @FindBy(name = "")
    public WebElement subscribeNewsletterBox;
    @FindBy(name = "")
    public WebElement subscribeNewsletterBtn;



    public String getUrl() {
        return url;
    }

    public void goToUrl(String url) throws InterruptedException {
        driver.get(url);
    }


    public WebElement getHomePageSlider() {
        return homePageSlider;
    }

    public List<WebElement> getContainerFeaturedProducts() {
        return containerFeaturedProducts;
    }

    public WebElement getFooterBanners() {
        return footerBanners;
    }

    public List<WebElement> getLatestProducts() {
        return latestProducts;
    }

    public List<WebElement> getBestSellerProducts() {
        return bestSellerProducts;
    }

    public List<WebElement> getSpecialProducts() {
        return specialProducts;
    }

    public List<WebElement> getBrandScrollingList() {
        return BrandScrollingList;
    }

    public WebElement getContactUs() {
        return contactUs;
    }

    public WebElement getAboutUs() {
        return aboutUs;
    }

    public WebElement getTestimonials() {
        return testimonials;
    }

    public WebElement getNewsletterSignUpsTxt() {
        return newsletterSignUpsTxt;
    }

    public WebElement getSubscribeNewsletterBox() {
        return subscribeNewsletterBox;
    }

    public WebElement getSubscribeNewsletterBtn() {
        return subscribeNewsletterBtn;
    }



}
