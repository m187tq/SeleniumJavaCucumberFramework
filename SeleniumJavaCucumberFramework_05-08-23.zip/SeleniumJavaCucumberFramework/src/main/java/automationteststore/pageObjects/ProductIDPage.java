package automationteststore.pageObjects;

import automationteststore.AbstractComponents.AbstractComponent;
import automationteststore.helper.assertion.VerificationHelper;
import automationteststore.helper.logger.LoggerHelper;
import automationteststore.pageObjects.AccountPages.AccountCreatePage;
import automationteststore.pageObjects.AccountPages.AccountLoginPage;
import automationteststore.pageObjects.HomePages.HomePage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class ProductIDPage extends AbstractComponent {
    public WebDriver driver;

    Logger log = LoggerHelper.getLogger(ProductIDPage.class);
    public ProductIDPage(WebDriver driver) throws IOException {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    @FindBy(xpath="")
    private WebElement XXXXXXXX;


}
