package automationteststore.pageObjects;

import automationteststore.AbstractComponents.AbstractComponent;
import automationteststore.helper.logger.LoggerHelper;
import automationteststore.helperutilities.GlobalVars;
import automationteststore.pageObjects.OrderPage.OrderConfirmationPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class AddToCartPage extends AbstractComponent {
    public WebDriver driver;
    Logger log = LoggerHelper.getLogger(AddToCartPage.class);
    public AddToCartPage(WebDriver driver) throws IOException {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@id=\"quickSearch\"]/div/section/ul/li[2]")
    public WebElement addToCartByIndex;

    @FindBy(id="quantity_wanted")
    private WebElement quantity;

    @FindBy(name="group_1")
    private WebElement size;

    @FindBy(xpath="//span[text()='Add to cart']")
    private WebElement addToCartBtn;

    @FindBy(xpath="//*[@id=\"layer_cart\"]//h2/i")
    private WebElement addToCartMessage;

    @FindBy(xpath="//span[contains(text(),'Proceed to checkout')]")
    private WebElement proceedToCheckOutBtn;

    public void enterQuantity(String quantity1) throws Throwable {
        sendKeys(quantity, quantity1);
    }
    public void clickOnAddToCart() throws Throwable {
        waitAndClickElement(addToCartBtn);
    }
    public String getAddToCart() throws Throwable {
        waitForElement(addToCartMessage, GlobalVars.getExplicitWait());
        return verificationHelper.getText(addToCartMessage);
    }
    public OrderConfirmationPage clickOnCheckOut() throws Throwable {
        fluentWait(driver, proceedToCheckOutBtn, GlobalVars.getExplicitWait());
        waitAndClickElement(proceedToCheckOutBtn);
        return new OrderConfirmationPage(driver);
    }
    public void ClickOnAddToCartByIndex() {
        moveToElement(driver,addToCartByIndex);
        JSClick(driver,addToCartByIndex);
    }

}
