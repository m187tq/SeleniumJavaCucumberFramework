package automationteststore.helperutilities;

public enum OSType {
	MACOS, WINDOWS10, LINUX
}
