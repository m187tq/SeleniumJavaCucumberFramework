package automationteststore.helperutilities;

public class SpecialCharacterGeneratorUtils {

	/*
	 * private static final CharSequence[] SPECIAL_CHARACTER_SEQUENCE = new char[]
	 * {'!', '#', '$', '%', '&', ''', '*', '+', '-', '/', '=', '?', '^', '_', '`',
	 * '{', ' | ', '}', '~', ';','.' ,'(' ,')'}; private static int currentIndex =
	 * 0;
	 * 
	 * public static char enterSpecialCharacter(WebElement element) { for (int i =
	 * currentIndex; i < SPECIAL_CHARACTER_SEQUENCE.length; i++) {
	 * element.sendKeys(SPECIAL_CHARACTER_SEQUENCE[i]); currentIndex++; break; } }
	 */

}
