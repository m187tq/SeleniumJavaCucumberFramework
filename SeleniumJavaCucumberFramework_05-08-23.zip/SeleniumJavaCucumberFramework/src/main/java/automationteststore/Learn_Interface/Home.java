package automationteststore.Learn_Interface;

public interface Home {
    void isDisplayed();

}
