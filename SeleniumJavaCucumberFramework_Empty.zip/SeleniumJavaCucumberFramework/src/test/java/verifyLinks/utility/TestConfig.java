package verifyLinks.utility;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class TestConfig {
  
	public static WebDriver driver;
	
	@BeforeSuite
	public void beforeSuite() {

		WebDriverManager.chromedriver().setup();
		ChromeOptions ops = new ChromeOptions();
		ops.addArguments("--remote-allow-origins=*");
		WebDriver driver = new ChromeDriver(ops);
		  
	  }
	
	  @AfterSuite
	  public void afterSuite() throws InterruptedException {
		  
		  System.out.println("Completed Suite");
		  
		  Thread.sleep(3000);
		  driver.quit();
	  
	  }

}
