package verifyLinks.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import verifyLinks.utility.TestConfig;


public class verifyLinksTests extends TestConfig {
  
	@Test
  public void VerifyLinksTests() throws InterruptedException {
	  
		/*Bottom Row Links*/
		//Gmail link
		driver.findElement(By.linkText("Gmail")).click();
		driver.navigate().back();
		
		//Images link
		driver.findElement(By.linkText("Images")).click();
		driver.navigate().back();
		
		//Google apps link
		driver.findElement(By.xpath("//*[@id='gbwa']/div[1]/a")).click();
		driver.navigate().back();
		
		//Sign in link
		driver.findElement(By.xpath("//*[@id='gb_70']")).click();
		driver.navigate().back();
		
		/*Bottom Row Links*/
		//Advertising link
		driver.findElement(By.linkText("Advertising")).click();
		driver.navigate().back();
		
		//Business link
		driver.findElement(By.linkText("Business")).click();
		driver.navigate().back();
		driver.navigate().back();
		
		
		//About link
		driver.findElement(By.linkText("About")).click();
		driver.navigate().back();
		
		
		//Privacy link
		driver.findElement(By.linkText("Privacy")).click();
		driver.navigate().back();
		
		//Terms link
		driver.findElement(By.linkText("Terms")).click();
		driver.navigate().back();
		
		//Settings link
		driver.findElement(By.linkText("Settings")).click();
		driver.navigate().back();
		

		
  }
  

}
