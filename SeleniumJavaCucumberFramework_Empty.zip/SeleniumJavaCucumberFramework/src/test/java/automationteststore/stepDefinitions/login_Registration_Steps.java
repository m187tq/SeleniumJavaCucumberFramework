package automationteststore.stepDefinitions;

import automationteststore.TestComponents.BaseTest;
import io.cucumber.java.en.Given;

import java.io.IOException;


public class login_Registration_Steps extends BaseTest {
    //HomePage homePage;

    @Given("I landed on Ecommerce home Page {string}")
    public void iLandedOnEcommerceHomePage(String url) throws IOException {
        /*homePage = launchApplication();
        AssertionHelper.updateTestStatus(homePage.getCurrentPageUrl().contains(url));
        AssertionHelper.updateTestStatus(homePage.verifyLogoImageVisibility());
        homePage.clickOnCookie();*/

    }


}



