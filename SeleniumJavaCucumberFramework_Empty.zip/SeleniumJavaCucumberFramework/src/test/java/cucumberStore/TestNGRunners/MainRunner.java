package cucumberStore.TestNGRunners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//cucumber->  TestNG, junit

@CucumberOptions(features="src/test/java/cucumberStore",
        glue="automationteststore.stepDefinitions",
        monochrome=true,
        //tags = "AccountRegistration",
        //tags = "@Accordion",
        //tags = "@Actions"
        //tags = "@BrowserTabs",
        //tags = "@Buttons",
        tags = "@TestStoreTest",
        plugin= {"html:target/cucumber.html"})

public class MainRunner extends AbstractTestNGCucumberTests{
   /*@Override
	@DataProvider(parallel=true)
	public Object[][] scenarios() {
		return super.scenarios();
	}*/
	
}
