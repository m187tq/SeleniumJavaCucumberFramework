package automationteststore.exceptions;

public class CriteriaSetNumberException extends Exception {

	public CriteriaSetNumberException(String message) {
		super(message);
	}

}
