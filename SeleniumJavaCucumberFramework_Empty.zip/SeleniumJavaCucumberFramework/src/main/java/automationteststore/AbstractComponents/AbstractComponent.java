package automationteststore.AbstractComponents;

import automationteststore.helper.alert.AlertHelper;
import automationteststore.helper.assertion.VerificationHelper;
import automationteststore.helper.javaScript.JavaScriptHelper;
import automationteststore.helper.logger.LoggerHelper;
import automationteststore.helper.wait.WaitHelper;
import automationteststore.helperutilities.GlobalVars;
import com.google.common.collect.Ordering;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;

import java.time.Duration;
import java.util.*;

public class AbstractComponent {
	public AbstractComponent(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
		verificationHelper = new VerificationHelper(driver);
		js = new JavaScriptHelper(driver);
		wait = new WebDriverWait(driver, Duration.ofSeconds(GlobalVars.DEFAULT_EXPLICIT_TIMEOUT));
	}
	WebDriver driver;
	protected WebDriverWait wait;
	public WaitHelper waitHelper;
	public VerificationHelper verificationHelper;
	public AlertHelper alertHelper;
	Logger log = LoggerHelper.getLogger(AbstractComponent.class);
	public JavaScriptHelper js;


	public final String url = "https://automationteststore.com/";

	public String getHeaderTxt() {
		return verificationHelper.getText(headerTxt);
	}

	@FindBy(xpath = "//h2[@id='content']")
	public WebElement headerTxt;

	/*public LoginPage goToLoginPageFromIndexPage() {
		indexSignInBtn.click();
		loginPage = new LoginPage(driver);
		return loginPage;
	}*/

	public String getCurrentPageUrl() {
		return verificationHelper.getCurrentUrl();
	}

	public String getCurrentPageTitle() {
		return verificationHelper.getTitle();
	}

	public void waitForElementToAppear(By findBy) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(findBy));
	}

	public void waitForListOfElementsToAppear(By findBy) {
		new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(findBy));
	}

	public void waitForWebElementToAppear(WebElement findBy) {
		log.info("Waiting for element to be visible...");
		wait.until(ExpectedConditions.visibilityOf(findBy));
	}

	public void waitAndSendKeys(WebElement findBy, String keysToSend){
		findBy.clear();
		wait.until(ExpectedConditions.visibilityOf(findBy)).sendKeys(keysToSend);
	}

	public void waitAndClick(WebElement findBy){
		wait.until(ExpectedConditions.elementToBeClickable(findBy)).click();
		log.info("Element clicked....");
	}

	public void waitForElementToDisappear(WebElement ele) {
		wait.until(ExpectedConditions.invisibilityOf(ele));

	}

	public void SwitchWindowToChild() {
		Set<String> s1=driver.getWindowHandles();
		Iterator<String> i1 =s1.iterator();
		String parentWindow = i1.next();
		String childWindow = i1.next();
		driver.switchTo().window(childWindow);
	}

	public void navigateToApplicationUrl(String url) {
		driver.get(url);
		log.info("navigating to >> : +url");
	}

	public void getApplicationUrl(String url) {
		driver.get(url);
		log.info("navigating to ..." + url);
	}

	public void navigateToUrl(String url) {
		log.info("navigates to the url: " + url);
		driver.get(url);
	}

	public String generateRandomNumber(int length) {
		log.info("Entered generated Random loginName.... ");
		return RandomStringUtils.randomNumeric(length);
	}

	public String generateRandomString(int length) {
		return RandomStringUtils.randomAlphabetic(length);
	}

	public void sendKeys(By by, String textToType) {
		log.info("Entered text :" + textToType);
		wait.until(ExpectedConditions.elementToBeClickable(by)).sendKeys(textToType);
	}

	public void sendKeys(WebElement element, String textToType) {
		element.clear();
		log.info("Entered text :" + textToType);
		wait.until(ExpectedConditions.elementToBeClickable(element)).sendKeys(textToType);
	}

	public void waitFor(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void waitForWebElementAndClick(By by) {
		log.info("Waited and clicked on the element: ");
		wait.until(ExpectedConditions.elementToBeClickable(by)).click();
		//wait.until(d -> element.isDisplayed());
	}

	public void waitForWebElementAndClick(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element)).click();
		log.info("Successfully clicked on "+ element.getText());
	}

	public void waitForAndClick(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element)).click();
		log.info("It is visible now.... " + element.getText());
		System.out.println("Clicked on the element => " + element.getText());
		log.info("Clicked on the element => " + element.getText());
		element.click();
	}

	public void waitForAndSendKeys(WebElement element, String textToSend) {
		wait.until(d -> element.isDisplayed());
		element.clear();
		element.sendKeys(textToSend);
		log.info("Waited and send on the element: " + element.getText());
	}

	public void waitForAlert_And_ValidateText(String text) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(GlobalVars.DEFAULT_EXPLICIT_TIMEOUT));
		wait.until(ExpectedConditions.alertIsPresent());
		String alert_Message_Text = driver.switchTo().alert().getText();
		Assert.assertEquals(alert_Message_Text, text);
	}


	public void  clickMatchingElementByText(List<WebElement> elements, String productName){
		WebElement element =  elements
				.stream()
				.parallel()
				.filter(s -> s.getText().equalsIgnoreCase(productName))
				.findFirst()
				.orElseThrow(()-> new RuntimeException("Element with text" + productName + "not present"));
		element.click();

	}

	public int getCountWebElements(WebElement element) {
		log.info("Count element: " + element.getText());
		return driver.findElements((By) element).size();
	}

	public List<String> getAccountsSectionsList(List<WebElement> products) {
		List<String> accountsList = new ArrayList<>();
		List<WebElement> accountsHeaderList = driver.findElements((By) products);
		for (WebElement e : accountsHeaderList) {
			String text = e.getText();
			log.info(text);
			accountsList.add(text);
		}
		return accountsList;
	}

	// =================================Wait===========================================

	public void setImplicitWait(long timeout) {
		log.info("Implicit Wait has been set to: " + timeout);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));
	}

	public void WaitForElementClickable(WebElement element, int timeOutInSeconds) {
		log.info("waiting for :" + element.toString() + " for :" + timeOutInSeconds + " seconds");
		wait.until(ExpectedConditions.elementToBeClickable(element));
		log.info("element is clickable now");
	}

	public boolean waitForElementNotPresent(WebElement element, long timeOutInSeconds) {
		log.info("waiting for :" + element.toString() + " for :" + timeOutInSeconds + " seconds");
		boolean status = wait.until(ExpectedConditions.invisibilityOf(element));
		log.info("element is invisibile now");
		return status;
	}

	public void waitForFrameToBeAvailableAndSwitchToIt(WebElement element, long timeOutInSeconds) {
		log.info("waiting for :" + element.toString() + " for :" + timeOutInSeconds + " seconds");
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
		log.info("frame is available and switched");
	}

	private Wait<WebDriver> getfluentWait(int timeOutInSeconds, int pollingEveryInMiliSec) {
		Wait<WebDriver> fWait = new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(timeOutInSeconds))
				.pollingEvery(Duration.ofMillis(pollingEveryInMiliSec)).ignoring(NoSuchElementException.class);
		return fWait;
	}

	public void waitForElement(WebElement element, int timeOutInSeconds) {
		log.info("waiting for :" + element.toString() + " for :" + timeOutInSeconds + " seconds");
		wait.until(ExpectedConditions.visibilityOf(element));
		log.info("element is visible now");
	}

	//=====================Alerts=====================================

	public Alert getAlert() {
		log.info("alert test: " + driver.switchTo().alert().getText());
		return driver.switchTo().alert();
	}

	public void acceptAlert() {
		getAlert().accept();
		log.info("accept Alert is done...");
	}

	public void dismissAlert() {
		getAlert().dismiss();
		log.info("dismiss Alert is done...");
	}

	public String getAlertText() {
		String text = getAlert().getText();
		log.info("alert text: " + text);
		return text;
	}

	public boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			log.info("alert is present");
			return true;
		} catch (NoAlertPresentException e) {
			log.info(e.getCause());
			return false;
		}
	}

	public void acceptAlertIfPresent() {
		if (isAlertPresent()) {
			acceptAlert();
		} else {
			log.info("Alert is not present..");
		}
	}

	public void dismissAlertIfPresent() {
		if (isAlertPresent()) {
			dismissAlert();
		} else {
			log.info("Alert is not present..");
		}
	}

	public void acceptPrompt(String text) {
		if (isAlertPresent()) {
			Alert alert = getAlert();
			alert.sendKeys(text);
			alert.accept();
			log.info("alert text: " + text);
		}
	}

	//====================Dropdowns============================================

	public void SelectUsingVisibleValue(WebElement element, String visibleValue) {
		Select select = new Select(element);
		select.selectByVisibleText(visibleValue);
		log.info("Locator : " + element + " Value : " + visibleValue);
	}

	public String getSelectedValue(WebElement element) {
		String value = new Select(element).getFirstSelectedOption().getText();
		log.info("WebElement : " + element + " Value : " + value);
		return value;
	}

	public void SelectUsingIndex(WebElement element, int index) {
		Select select = new Select(element);
		select.selectByIndex(index);
		log.info("Locator : " + element + " Value : " + index);
	}

	public void SelectUsingVisibleText(WebElement element, String text) {
		Select select = new Select(element);
		select.selectByVisibleText(text);
		log.info("Locator : " + element + " Value : " + text);
	}


	public List<String> getAllDropDownValues(WebElement locator) {
		Select select = new Select(locator);
		List<WebElement> elementList = select.getOptions();
		List<String> valueList = new LinkedList<String>();
		for (WebElement element : elementList) {
			log.info(element.getText());
			valueList.add(element.getText());
		}
		return valueList;
	}


	//================================Verify=====================================

	/**
	 * Checks whether actual String contains expected string and prints both in log
	 *
	 * @param actualText - actual Text picked up from application under Test
	 * @param expText    - expected Text to be checked with actual text
	 * @return boolean result
	 */
	public boolean verifyTextContains(String actualText, String expText) {
		if (actualText.toLowerCase().contains(expText.toLowerCase())) {
			log.info("Actual Text From Web Application UI   --> : " + actualText);
			log.info("Expected Text From Web Application UI --> : " + expText);
			log.info("### Verification Contains !!!");
			return true;
		} else {
			log.info("Actual Text From Web Application UI   --> : " + actualText);
			log.info("Expected Text From Web Application UI --> : " + expText);
			log.info("### Verification DOES NOT Contains !!!");
			return false;
		}

	}

	public boolean verifyTextMatch(String actualText, String expText) {
		if (actualText.equals(expText)) {
			log.info("Actual Text From Web Application UI   --> : " + actualText);
			log.info("Expected Text From Web Application UI --> : " + expText);
			log.info("### Verification MATCHED !!!");
			return true;
		} else {
			log.info("Actual Text From Web Application UI   --> : " + actualText);
			log.info("Expected Text From Web Application UI --> : " + expText);
			log.info("### Verification DOES NOT MATCH !!!");
			return false;
		}
	}

	public Boolean verifyListContains(List<String> actList, List<String> expList) {
		int expListSize = expList.size();
		for (int i = 0; i < expListSize; i++) {
			if (!actList.contains(expList.get(i))) {
				return false;
			}
		}
		log.info("Actual List Contains Expected List !!!");
		return true;
	}

	public Boolean verifyListMatch(List<String> actList, List<String> expList) {
		boolean found = false;
		int actListSize = actList.size();
		int expListSize = expList.size();
		if (actListSize != expListSize) {
			return false;
		}

		for (int i = 0; i < actListSize; i++) {
			found = false;
			for (int j = 0; j < expListSize; j++) {
				if (verifyTextMatch(actList.get(i), expList.get(j))) {
					found = true;
					break;
				}
			}
		}
		if (found) {
			log.info("Actual List Matches Expected List !!!");
			return true;
		} else {
			log.info("Actual List DOES NOT Match Expected List !!!");
			return false;
		}
	}

	public Boolean verifyItemPresentInList(List<String> actList, String item) {
		int actListSize = actList.size();
		for (int i = 0; i < actListSize; i++) {
			if (!actList.contains(item)) {
				log.info("Item is NOT present in List !!!");
				return false;
			}
		}
		log.info("Item is present in List !!!");
		return true;
	}

	public boolean isListAscendingOrder(List<Long> list) {
		return Ordering.natural().isOrdered(list);
	}

	//====================Generator==================================

	public int getRandomNumber(int min, int max) {
		int diff = max - min;
		int randomNum = (int) (min + Math.random() * diff);
		log.info("Random Number :: " + randomNum +
				" within range :: " + min + " and :: " + max);
		return randomNum;
	}

	public int getRandomNumber(int number) {
		return getRandomNumber(1, number);
	}

	public String getRandomString(int length) {
		StringBuilder sbuilder = new StringBuilder();
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		for (int i = 0; i < length; i++) {
			int index = (int) (Math.random() * chars.length());
			sbuilder.append(chars.charAt(index));
		}
		String randomString = sbuilder.toString();
		log.info("Random string with length :: "
				+ length + " is :: " + randomString);
		return randomString;
	}

	public String getRandomString() {
		return getRandomString(10);
	}

	//======================Validation============================================

	public boolean isDisplayed(WebElement element){
		try{
			element.isDisplayed();
			log.info("element is Displayed.."+element.getText());
			return true;
		} catch(Exception e){
			log.error("element is not Displayed..", e.getCause());
			return false;
		}
	}

	public boolean isEnabled(WebElement element){
		try{
			element.isEnabled();
			log.info("element is enabled.."+element.getText());
			return true;
		} catch(Exception e){
			log.error("element is not enabled..", e.getCause());
			return false;
		}
	}

	public boolean isSelected(WebElement element) {
		try{
			element.isSelected();
			log.info("The element is Selected:  " + "<" + element + ">");
			return true;
		} catch(Exception e){
			log.info("The element is not Selected.... ");
			log.error("The element is not Selected: ", e.getCause());
			return false;
		}
	}

	public boolean isNotDisplayed(WebElement element){
		try{
			element.isDisplayed();
			log.info("element is present.."+element.getText());
			return false;
		} catch(Exception e){
			log.error("element is not present..");
			return true;
		}
	}

	public String readValueFromElement(WebElement element){
		if(null == element){
			log.info("WebElement is null..");
			return null;
		}
		boolean status = isDisplayed(element);
		if(status){
			log.info("element text is .."+element.getText());
			return element.getText();
		} else{
			return null;
		}
	}

	public String getText(WebElement element){
		if(null == element){
			log.info("WebElement is null..");
			return null;
		}
		boolean status = isDisplayed(element);
		if(status){
			log.info("element text is .."+element.getText());
			return element.getText();
		} else{
			return null;
		}
	}

	public String getTitle(){
		log.info("page title is: "+driver.getTitle());
		return driver.getTitle();
	}

	//==================================================================================

	/**
	 * this method will switchToFrame based on frame index
	 *
	 * @param frameIndex
	 */
	public void switchToFrame(int frameIndex) {
		driver.switchTo().frame(frameIndex);
		log.info("switched to :" + frameIndex + " frame");
	}

	/**
	 * this method will switchToFrame based on frame name
	 *
	 * @param frameName
	 */
	public void switchToFrame(String frameName) {
		driver.switchTo().frame(frameName);
		log.info("switched to :" + frameName + " frame");
	}

	/**
	 * this method will switchToFrame based on frame WebElement
	 *
	 * @param element
	 */
	public void switchToFrame(WebElement element) {
		driver.switchTo().frame(element);
		log.info("switched to frame " + element.toString());
	}

	//====================Window======================================

	/**
	 * This method will switch to parent window
	 */
	public void switchToParentWindow() {
		log.info("switching to parent window...");
		driver.switchTo().defaultContent();
	}

	/**
	 * This method will switch to child window based on index
	 *
	 * @param index
	 */
	public void switchToWindow(int index) {
		Set<String> windows = driver.getWindowHandles();
		int i = 1;
		for (String window : windows) {
			if (i == index) {
				log.info("switched to : " + index + " window");
				driver.switchTo().window(window);
			} else {
				i++;
			}
		}
	}


	public void closeAllTabsAndSwitchToMainWindow() {
		Set<String> windows = driver.getWindowHandles();
		String mainwindow = driver.getWindowHandle();

		for (String window : windows) {
			if (!window.equalsIgnoreCase(mainwindow)) {
				driver.close();
			}
		}
		log.info("switched to main window");
		driver.switchTo().window(mainwindow);
	}

	/**
	 * This method will do browser back navigation
	 */
	public void navigateBack() {
		log.info("navigating back");
		driver.navigate().back();
	}

	/**
	 * This method will do browser forward navigation
	 */
	public void navigateForward() {
		log.info("navigating forward");
		driver.navigate().forward();
	}

	//==================JavascriptExecutor=============================================

	public void scrollByVisibilityOfElement(WebDriver driver, WebElement ele) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", ele);

	}

	public boolean JSClick(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
			// driver.executeAsyncScript("arguments[0].click();", element);

			flag = true;

		} catch (Exception e) {
			throw e;

		} finally {
			if (flag) {
				log.info("Click Action is performed: " +ele.getText());
			} else if (!flag) {
				log.info("Click Action is not performed: " +ele.getText());
			}
		}
		return flag;
	}

//===============Actions===================================================

	public void mouseOverElement(WebDriver driver,WebElement element) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(element).build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				log.info(" MouserOver Action is performed on: " +element.getText());
			} else {
				log.info("MouseOver action is not performed on");
			}
		}
	}


	public boolean moveToElement(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].scrollIntoView(true);", ele);
			Actions actions = new Actions(driver);
			// actions.moveToElement(driver.findElement(locator)).build().perform();
			actions.moveToElement(ele).build().perform();
			flag = true;
			log.info(" Moving to the element & Action is performed on: " +ele.getText());
		} catch (Exception e) {
			log.info(" Action Not performed on: " +ele.getText());
			e.printStackTrace();
		}
		return flag;
	}


	public boolean mouseover(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(ele).build().perform();
			flag = true;
			log.info(" MouserOver Action is performed on: " +ele.getText());
			return true;
		} catch (Exception e) {
			log.info("MouseOver action is not performed on: " +ele.getText());
			return false;
		} finally {
			/*
			 * if (flag) {
			 * SuccessReport("MouseOver ","MouserOver Action is performed on \""+locatorName
			 * +"\""); } else {
			 * failureReport("MouseOver","MouseOver action is not performed on \""
			 * +locatorName+"\""); }
			 */
		}
	}

	public boolean draggable(WebDriver driver,WebElement source, int x, int y) {
		boolean flag = false;
		try {
			new Actions(driver).dragAndDropBy(source, x, y).build().perform();
			Thread.sleep(5000);
			flag = true;
			return true;

		} catch (Exception e) {
			return false;

		} finally {
			if (flag) {
				log.info("Draggable Action is performed on \""+source+"\"");
			} else if(!flag) {
				log.info("Draggable action is not performed on \""+source+"\"");
			}
		}
	}

	public boolean dragAndDrop(WebDriver driver,WebElement source, WebElement target) {
		boolean flag = false;
		try {
			new Actions(driver).dragAndDrop(source, target).perform();
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				log.info("DragAndDrop Action is performed");
			} else if(!flag) {
				log.info("DragAndDrop Action is not performed");
			}
		}
	}

	public boolean slider(WebDriver driver,WebElement ele, int x, int y) {
		boolean flag = false;
		try {
			// new axe(driver).dragAndDropBy(dragitem, 400, 1).build()
			// .perform();
			new Actions(driver).dragAndDropBy(ele, x, y).build().perform();// 150,0
			Thread.sleep(5000);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				log.info("Slider Action is performed");
			} else {
				log.info("Slider Action is not performed");
			}
		}
	}

	public boolean getText(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			ele.getText();
			flag = true;
		} catch (Exception e) {
			log.info("Got element text : " + ele.getText());
			flag = false;
		} finally {
			if (flag) {
				log.info("Successfully Found element text: " + ele.getText());

			} else {
				log.info("Unable to get element text..." + ele.getText());
			}
		}
		return flag;
	}

	public boolean verifyHeaderTxtIsDisplayed(WebElement element) {
		return verificationHelper.isDisplayed(element);
	}
}

