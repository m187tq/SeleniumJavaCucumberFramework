package automationteststore.model.employer;


import automationteststore.model.FieldInputModel;

public class CreateAPersonSpecificationPageFieldInputModel extends FieldInputModel {

	public CreateAPersonSpecificationPageFieldInputModel() {
		fieldInputData.put("Skill Category", "Communication");
		fieldInputData.put("Essential Skill", "Communication");
		fieldInputData.put("Desirable Skill", "Critical Thinking");
	}

}
