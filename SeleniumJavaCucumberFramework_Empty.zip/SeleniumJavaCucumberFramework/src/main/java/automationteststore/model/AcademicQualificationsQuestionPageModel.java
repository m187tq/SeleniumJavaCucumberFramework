package automationteststore.model;

public class AcademicQualificationsQuestionPageModel extends FieldInputModel {
	public AcademicQualificationsQuestionPageModel() {
		fieldInputData.put("yesOrNo", "Yes");
	}
}
