package automationteststore.helperutilities;

public class PageException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4699775993150102769L;

	public PageException(String message) {
		super(message);
	}

}
